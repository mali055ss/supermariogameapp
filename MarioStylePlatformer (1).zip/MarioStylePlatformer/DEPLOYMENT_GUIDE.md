
# Super Mario Platformer - Deployment Guide

## Para sa GitHub Repository Setup

### 1. Mag-create ng GitHub Account (kung wala pa)
- Pumunta sa https://github.com
- I-click ang "Sign up"
- Gumawa ng account

### 2. Mag-create ng New Repository
1. **I-click ang "+" icon** sa upper right ng GitHub
2. **Piliin ang "New repository"**
3. **Repository name**: `super-mario-platformer`
4. **Description**: "Super Mario Platformer Game built with React, TypeScript, and Express.js"
5. **I-set as Public** para makita ng lahat
6. **I-click ang "Create repository"**

### 3. I-connect ang Replit Project sa GitHub

**Option A: Automatic Setup (Recommended)**
```bash
# I-run ang setup script
chmod +x setup-github.sh
./setup-github.sh
```

**Option B: Manual Setup**
```bash
# I-set ang Git user info (first time lang)
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"

# I-add ang GitHub repository (replace YOUR-USERNAME)
git remote add origin https://github.com/YOUR-USERNAME/super-mario-platformer.git

# I-rename ang branch to main
git branch -M main

# I-push ang code sa GitHub
git push -u origin main
```

### 4. I-Deploy sa Replit

1. **I-click ang "Deploy" button** sa Replit (sa taas ng screen)
2. **Piliin ang deployment tier** na gusto ninyo
3. **I-verify ang build/run commands**:
   - Build command: `npm run build`
   - Run command: `npm run start`
4. **I-click ang "Deploy"** button
5. **Antayin** ang deployment process
6. **I-copy ang live URL** na makukuha ninyo

## Mga Makukuhang URLs:

✅ **GitHub Repository**: `https://github.com/YOUR-USERNAME/super-mario-platformer`  
✅ **Live Game URL**: `https://super-mario-platformer.replit.app`  
✅ **Source Code**: Makikita sa GitHub repository  
✅ **Playable Game**: Accessible worldwide via live URL  

## Final Steps:

1. **I-replace ang YOUR-USERNAME** sa GitHub URL with actual username ninyo
2. **I-update ang README.md** with actual deployment URL
3. **I-share ang links** sa social media, portfolio, etc.
4. **I-test** ang game sa different devices

*Congratulations! Ang Super Mario game ninyo ay live na at accessible worldwide! 🎮🌍*
