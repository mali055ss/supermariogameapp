# Super Mario Platformer Game 🎮

A classic 2D side-scrolling Mario-inspired platformer game built with React and HTML5 Canvas.

## 🚀 Play Online

**Live Demo:** [Coming Soon - Deploy this to see your game!]

## ✨ Features

- **Authentic Mario Character** - Pixel-perfect Mario with red hat, blue overalls, and classic animations
- **Multiple Levels** - Grassland, underground, and castle themed levels
- **Power-ups** - Mushroom (grow bigger), Fire Flower (shoot fireballs), Star (invincibility)
- **Enemies** - Mushrooms and flying turtles with AI behavior
- **Classic Mechanics** - Jump on enemies, collect coins, reach the flag
- **Sound Effects** - Jump, coin, power-up, and background music
- **Pause System** - ESC key or pause button to pause/resume
- **Mobile Friendly** - Works on all devices

## 🎮 How to Play

- **Arrow Keys** or **WASD** - Move left/right
- **Spacebar** - Jump
- **ESC** - Pause/Resume game
- **Goal** - Reach the flag at the end of each level
- **Collect** - Coins for points, power-ups for abilities
- **Avoid** - Enemies (or jump on them to defeat)

## 🛠️ Tech Stack

- **Frontend:** React + TypeScript
- **Graphics:** HTML5 Canvas
- **Styling:** Tailwind CSS
- **Audio:** HTML5 Audio API
- **Build:** Vite
- **Deployment:** GitHub Pages / Vercel / Netlify

## 📦 Quick Deploy

### Option 1: GitHub Pages (Free Forever)
1. Create new repository on GitHub
2. Upload all files from this project
3. Go to Settings → Pages → Deploy from branch: main
4. Your game will be live at: `https://yourusername.github.io/repository-name/`

### Option 2: Vercel (Fastest)
1. Go to [vercel.com](https://vercel.com)
2. Import this repository
3. Click Deploy
4. Live in 30 seconds!

### Option 3: Netlify (Easiest)
1. Go to [netlify.com](https://netlify.com)
2. Drag project folder to deploy area
3. Instant worldwide access!

## 🎯 Game Features

### Player Mechanics
- **Small Mario** - Standard size, dies in one hit
- **Big Mario** - Grows after mushroom power-up, survives one hit
- **Fire Mario** - Shoots fireballs after fire flower
- **Star Mario** - Temporary invincibility with star power-up

### Level Design
- **Dynamic Camera** - Follows player smoothly
- **Collision Detection** - Precise AABB collision system
- **Multiple Themes** - Each level has unique visual style
- **Progressive Difficulty** - More enemies and challenges per level

### Audio System
- **Background Music** - Classic platformer soundtrack
- **Sound Effects** - Jump, coin collection, power-up sounds
- **Mute Toggle** - Control audio in pause menu

## 🌐 Worldwide Access

Once deployed, your game will be:
- ✅ **Accessible globally** - Anyone can play
- ✅ **No downloads required** - Plays in web browser
- ✅ **Mobile compatible** - Works on phones and tablets
- ✅ **HTTPS secure** - Safe to share anywhere
- ✅ **Free hosting** - No monthly costs

## 📱 Share Your Game

Perfect for:
- Gaming portfolios
- School projects
- Social media sharing
- Friend challenges
- Game development showcase

## 🔧 Local Development

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) to play locally.

## 📄 License

MIT License - Feel free to use and modify!

---

**Ready to deploy?** Follow the deployment guide and share your Mario game with the world! 🌍