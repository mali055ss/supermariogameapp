import { useEffect, useState } from "react";
import { GameCanvas } from "./components/game/GameCanvas";
import { GameMenu } from "./components/game/GameMenu";
import { GameUI } from "./components/game/GameUI";
import { LevelComplete } from "./components/game/LevelComplete";
import { PauseMenu } from "./components/game/PauseMenu";
import { useGameState } from "./lib/stores/useGameState";
import { useAudio } from "./lib/stores/useAudio";
import "@fontsource/inter";

function App() {
  const { gameState } = useGameState();
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();
  const [audioLoaded, setAudioLoaded] = useState(false);

  // Load audio files
  useEffect(() => {
    const loadAudio = async () => {
      try {
        // Load background music
        const bgMusic = new Audio('/sounds/background.mp3');
        bgMusic.loop = true;
        bgMusic.volume = 0.3;
        setBackgroundMusic(bgMusic);

        // Load sound effects
        const hitSound = new Audio('/sounds/hit.mp3');
        hitSound.volume = 0.5;
        setHitSound(hitSound);

        const successSound = new Audio('/sounds/success.mp3');
        successSound.volume = 0.7;
        setSuccessSound(successSound);

        setAudioLoaded(true);
        console.log('Audio files loaded successfully');
      } catch (error) {
        console.error('Error loading audio files:', error);
        setAudioLoaded(true); // Continue without audio
      }
    };

    loadAudio();
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  if (!audioLoaded) {
    return (
      <div className="w-full h-full bg-black flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative bg-black">
      {gameState === 'menu' && <GameMenu />}
      {gameState === 'playing' && (
        <>
          <GameCanvas />
          <GameUI />
        </>
      )}
      {gameState === 'paused' && (
        <>
          <GameCanvas />
          <GameUI />
          <PauseMenu />
        </>
      )}
      {gameState === 'levelComplete' && <LevelComplete />}
      {gameState === 'gameOver' && (
        <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
          <div className="text-white text-center">
            <h2 className="text-4xl font-bold mb-4">Game Over</h2>
            <button
              onClick={() => useGameState.getState().resetGame()}
              className="px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700"
            >
              Try Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
