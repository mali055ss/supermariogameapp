import { useEffect, useRef } from "react";
import { GameEngine } from "@/lib/game/GameEngine";
import { useGameState } from "@/lib/stores/useGameState";

export function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);
  const { gameState, currentLevel } = useGameState();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize game engine
    gameEngineRef.current = new GameEngine(canvas, currentLevel);
    gameEngineRef.current.start();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (gameEngineRef.current) {
        gameEngineRef.current.stop();
      }
    };
  }, [currentLevel]);

  useEffect(() => {
    if (gameEngineRef.current) {
      if (gameState === 'playing') {
        gameEngineRef.current.resume();
      } else {
        gameEngineRef.current.pause();
      }
    }
  }, [gameState]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 block"
      style={{ imageRendering: 'pixelated' }}
    />
  );
}
