import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";

export function GameMenu() {
  const { startGame } = useGameState();
  const { toggleMute, isMuted } = useAudio();

  const handleStartGame = () => {
    startGame();
  };

  return (
    <div className="w-full h-full bg-gradient-to-b from-blue-400 to-green-400 flex items-center justify-center">
      <div className="text-center text-white">
        <h1 className="text-6xl font-bold mb-8 text-shadow-lg" style={{ textShadow: '3px 3px 0px #000' }}>
          SUPER MARIO
        </h1>
        <h2 className="text-4xl font-bold mb-12 text-shadow-lg" style={{ textShadow: '2px 2px 0px #000' }}>
          PLATFORMER
        </h2>
        
        <div className="space-y-4">
          <button
            onClick={handleStartGame}
            className="block mx-auto px-8 py-4 bg-red-600 text-white text-xl font-bold rounded-lg border-4 border-red-800 hover:bg-red-700 transform hover:scale-105 transition-all shadow-lg"
            style={{ textShadow: '1px 1px 0px #000' }}
          >
            START GAME
          </button>
          
          <button
            onClick={toggleMute}
            className="block mx-auto px-6 py-2 bg-yellow-500 text-black text-lg font-bold rounded border-2 border-yellow-700 hover:bg-yellow-400 transition-all"
          >
            {isMuted ? '🔇 SOUND OFF' : '🔊 SOUND ON'}
          </button>
        </div>
        
        <div className="mt-12 text-lg">
          <p>Use ARROW KEYS or WASD to move</p>
          <p>SPACE to jump</p>
          <p>ESC to pause</p>
        </div>
      </div>
    </div>
  );
}
