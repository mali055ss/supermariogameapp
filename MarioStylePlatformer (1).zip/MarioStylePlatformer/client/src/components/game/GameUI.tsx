import { useGameState } from "@/lib/stores/useGameState";

export function GameUI() {
  const { lives, score, coins, currentLevel, pauseGame } = useGameState();

  const handlePause = () => {
    pauseGame();
  };

  return (
    <div className="absolute top-4 left-4 right-4 z-10">
      <div className="flex justify-between items-center text-white text-lg font-bold">
        <div className="bg-black bg-opacity-50 px-4 py-2 rounded">
          <span>MARIO</span>
        </div>
        
        <div className="bg-black bg-opacity-50 px-4 py-2 rounded">
          <span>{score.toString().padStart(6, '0')}</span>
        </div>
        
        <div className="bg-black bg-opacity-50 px-4 py-2 rounded">
          <span>COINS: {coins}</span>
        </div>
        
        <div className="bg-black bg-opacity-50 px-4 py-2 rounded">
          <span>LEVEL: {currentLevel}</span>
        </div>
        
        <div className="bg-black bg-opacity-50 px-4 py-2 rounded">
          <span>LIVES: {lives}</span>
        </div>
        
        <button
          onClick={handlePause}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded border-2 border-red-800 transition-all text-lg font-bold"
          style={{ textShadow: '1px 1px 0px #000' }}
        >
          ⏸️ PAUSE
        </button>
      </div>
    </div>
  );
}
