import { useGameState } from "@/lib/stores/useGameState";

export function LevelComplete() {
  const { nextLevel, score, coins, currentLevel } = useGameState();

  const handleNextLevel = () => {
    if (currentLevel < 3) {
      nextLevel();
    } else {
      // Game completed
      useGameState.getState().resetGame();
    }
  };

  const isGameComplete = currentLevel >= 3;

  return (
    <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
      <div className="text-white text-center bg-blue-900 p-8 rounded-lg border-4 border-white">
        <h2 className="text-4xl font-bold mb-4">
          {isGameComplete ? 'GAME COMPLETE!' : 'LEVEL COMPLETE!'}
        </h2>
        
        <div className="mb-6">
          <p className="text-xl mb-2">Score: {score}</p>
          <p className="text-xl mb-2">Coins: {coins}</p>
          <p className="text-xl">Level: {currentLevel}</p>
        </div>
        
        <button
          onClick={handleNextLevel}
          className="px-6 py-3 bg-green-600 text-white text-xl font-bold rounded hover:bg-green-700 border-2 border-green-800"
        >
          {isGameComplete ? 'PLAY AGAIN' : 'NEXT LEVEL'}
        </button>
      </div>
    </div>
  );
}
