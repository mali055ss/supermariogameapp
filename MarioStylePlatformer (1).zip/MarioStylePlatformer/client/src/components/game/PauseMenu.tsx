import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";

export function PauseMenu() {
  const { resumeGame, resetGame, restartLevel } = useGameState();
  const { toggleMute, isMuted } = useAudio();

  const handleResume = () => {
    resumeGame();
  };

  const handleRestart = () => {
    restartLevel();
  };

  const handleMainMenu = () => {
    resetGame();
  };

  return (
    <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-20">
      <div className="text-white text-center bg-blue-900 p-8 rounded-lg border-4 border-white">
        <h2 className="text-4xl font-bold mb-8" style={{ textShadow: '2px 2px 0px #000' }}>
          PAUSED
        </h2>
        
        <div className="space-y-4">
          <button
            onClick={handleResume}
            className="block mx-auto px-8 py-3 bg-green-600 text-white text-xl font-bold rounded border-2 border-green-800 hover:bg-green-700 transition-all min-w-48"
            style={{ textShadow: '1px 1px 0px #000' }}
          >
            RESUME
          </button>
          
          <button
            onClick={handleRestart}
            className="block mx-auto px-8 py-3 bg-yellow-600 text-white text-xl font-bold rounded border-2 border-yellow-800 hover:bg-yellow-700 transition-all min-w-48"
            style={{ textShadow: '1px 1px 0px #000' }}
          >
            RESTART LEVEL
          </button>
          
          <button
            onClick={toggleMute}
            className="block mx-auto px-8 py-3 bg-purple-600 text-white text-xl font-bold rounded border-2 border-purple-800 hover:bg-purple-700 transition-all min-w-48"
            style={{ textShadow: '1px 1px 0px #000' }}
          >
            {isMuted ? '🔇 SOUND OFF' : '🔊 SOUND ON'}
          </button>
          
          <button
            onClick={handleMainMenu}
            className="block mx-auto px-8 py-3 bg-red-600 text-white text-xl font-bold rounded border-2 border-red-800 hover:bg-red-700 transition-all min-w-48"
            style={{ textShadow: '1px 1px 0px #000' }}
          >
            MAIN MENU
          </button>
        </div>
        
        <div className="mt-8 text-lg">
          <p>Press ESC to resume</p>
        </div>
      </div>
    </div>
  );
}