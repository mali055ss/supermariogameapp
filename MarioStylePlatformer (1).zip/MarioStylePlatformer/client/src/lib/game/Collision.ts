export interface Bounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class Collision {
  static checkAABB(rect1: Bounds, rect2: Bounds): boolean {
    return (
      rect1.x < rect2.x + rect2.width &&
      rect1.x + rect1.width > rect2.x &&
      rect1.y < rect2.y + rect2.height &&
      rect1.y + rect1.height > rect2.y
    );
  }

  static checkPoint(point: { x: number; y: number }, rect: Bounds): boolean {
    return (
      point.x >= rect.x &&
      point.x <= rect.x + rect.width &&
      point.y >= rect.y &&
      point.y <= rect.y + rect.height
    );
  }

  static getOverlap(rect1: Bounds, rect2: Bounds): { x: number; y: number } {
    const overlapX = Math.min(rect1.x + rect1.width, rect2.x + rect2.width) - Math.max(rect1.x, rect2.x);
    const overlapY = Math.min(rect1.y + rect1.height, rect2.y + rect2.height) - Math.max(rect1.y, rect2.y);
    
    return { x: overlapX, y: overlapY };
  }

  static resolveCollision(movingRect: Bounds, staticRect: Bounds): { x: number; y: number } {
    const overlap = this.getOverlap(movingRect, staticRect);
    
    // Resolve collision by moving the minimum distance
    if (overlap.x < overlap.y) {
      // Horizontal collision
      if (movingRect.x < staticRect.x) {
        return { x: -overlap.x, y: 0 };
      } else {
        return { x: overlap.x, y: 0 };
      }
    } else {
      // Vertical collision
      if (movingRect.y < staticRect.y) {
        return { x: 0, y: -overlap.y };
      } else {
        return { x: 0, y: overlap.y };
      }
    }
  }
}
