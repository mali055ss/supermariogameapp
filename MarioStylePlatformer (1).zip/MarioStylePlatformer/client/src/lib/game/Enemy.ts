import { Level } from './Level';
import { Collision } from './Collision';

export abstract class Enemy {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number = 0;
  velocityY: number = 0;
  
  protected alive: boolean = true;
  protected facing: 'left' | 'right' = 'left';
  protected animationFrame: number = 0;
  protected animationTime: number = 0;
  
  protected readonly GRAVITY = 600;
  protected readonly MOVE_SPEED = 50;

  constructor(x: number, y: number, width: number, height: number) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.velocityX = -this.MOVE_SPEED;
  }

  update(deltaTime: number, level: Level) {
    if (!this.alive) return;
    
    // Apply gravity
    this.velocityY += this.GRAVITY * deltaTime;
    
    // Update position
    this.x += this.velocityX * deltaTime;
    this.y += this.velocityY * deltaTime;
    
    // Handle level collision
    this.handleLevelCollision(level);
    
    // Update animation
    this.animationTime += deltaTime;
    if (this.animationTime > 0.2) {
      this.animationFrame = (this.animationFrame + 1) % 2;
      this.animationTime = 0;
    }
    
    // Custom enemy behavior
    this.updateBehavior(deltaTime);
  }

  protected abstract updateBehavior(deltaTime: number): void;

  protected handleLevelCollision(level: Level) {
    // Ground collision
    const groundY = level.getGroundLevel(this.x);
    
    if (this.y + this.height >= groundY && this.velocityY >= 0) {
      this.y = groundY - this.height;
      this.velocityY = 0;
    }
    
    // Wall collision - turn around
    if (this.x <= 0 || this.x + this.width >= level.getWidth()) {
      this.velocityX = -this.velocityX;
      this.facing = this.facing === 'left' ? 'right' : 'left';
    }
  }

  kill() {
    this.alive = false;
  }

  isAlive(): boolean {
    return this.alive;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }

  abstract render(ctx: CanvasRenderingContext2D): void;
}

export class Mushroom extends Enemy {
  constructor(x: number, y: number) {
    super(x, y, 32, 32);
  }

  protected updateBehavior(deltaTime: number) {
    // Simple walking behavior - just keep moving
    // Direction changes are handled in wall collision
  }

  render(ctx: CanvasRenderingContext2D) {
    if (!this.alive) return;
    
    // Mushroom body (brown)
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(this.x, this.y + 10, this.width, this.height - 10);
    
    // Mushroom cap (red with white spots)
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(this.x - 4, this.y, this.width + 8, 20);
    
    // White spots
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 4, this.y + 4, 6, 6);
    ctx.fillRect(this.x + 18, this.y + 4, 6, 6);
    ctx.fillRect(this.x + 11, this.y + 12, 6, 6);
    
    // Eyes
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 8, this.y + 18, 3, 3);
    ctx.fillRect(this.x + 21, this.y + 18, 3, 3);
    
    // Feet
    ctx.fillStyle = '#654321';
    ctx.fillRect(this.x + 4, this.y + 28, 8, 4);
    ctx.fillRect(this.x + 20, this.y + 28, 8, 4);
  }
}

export class Turtle extends Enemy {
  private flying: boolean = true;
  private bobTime: number = 0;

  constructor(x: number, y: number) {
    super(x, y, 40, 30);
    this.velocityY = -20; // Start with upward movement
  }

  protected updateBehavior(deltaTime: number) {
    if (this.flying) {
      // Flying pattern - bob up and down
      this.bobTime += deltaTime * 3;
      this.velocityY = Math.sin(this.bobTime) * 50;
      
      // Don't apply gravity when flying
      this.velocityY -= this.GRAVITY * deltaTime;
    }
  }

  protected handleLevelCollision(level: Level) {
    if (this.flying) {
      // Keep flying above ground
      const groundY = level.getGroundLevel(this.x);
      if (this.y + this.height > groundY - 100) {
        this.velocityY = -50;
      }
      if (this.y < 50) {
        this.velocityY = 50;
      }
    } else {
      super.handleLevelCollision(level);
    }
    
    // Wall collision - turn around
    if (this.x <= 0 || this.x + this.width >= level.getWidth()) {
      this.velocityX = -this.velocityX;
      this.facing = this.facing === 'left' ? 'right' : 'left';
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    if (!this.alive) return;
    
    // Shell (green)
    ctx.fillStyle = '#00aa00';
    ctx.fillRect(this.x, this.y + 5, this.width, this.height - 10);
    
    // Shell pattern
    ctx.fillStyle = '#006600';
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(this.x + 5 + i * 10, this.y + 8, 8, 4);
      ctx.fillRect(this.x + 10 + i * 10, this.y + 15, 8, 4);
    }
    
    // Head
    ctx.fillStyle = '#00cc00';
    ctx.fillRect(this.x + this.width, this.y + 10, 10, 15);
    
    // Eyes
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + this.width + 2, this.y + 12, 2, 2);
    ctx.fillRect(this.x + this.width + 6, this.y + 12, 2, 2);
    
    // Wings (if flying)
    if (this.flying) {
      ctx.fillStyle = '#ffffff';
      const wingOffset = Math.sin(this.bobTime * 8) * 3;
      ctx.fillRect(this.x + 5, this.y - wingOffset, 12, 8);
      ctx.fillRect(this.x + 23, this.y - wingOffset, 12, 8);
    }
    
    // Legs
    ctx.fillStyle = '#00aa00';
    ctx.fillRect(this.x + 8, this.y + 25, 6, 8);
    ctx.fillRect(this.x + 18, this.y + 25, 6, 8);
    ctx.fillRect(this.x + 28, this.y + 25, 6, 8);
  }
}
