import { Player } from './Player';
import { Level } from './Level';
import { Enemy, Mushroom, Turtle } from './Enemy';
import { PowerUp, MushroomPowerUp, FireFlowerPowerUp, StarPowerUp } from './PowerUp';
import { Collision } from './Collision';
import { Particle } from './Particle';
import { useGameState } from '../stores/useGameState';
import { useAudio } from '../stores/useAudio';

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private player: Player;
  private level: Level;
  private enemies: Enemy[] = [];
  private powerUps: PowerUp[] = [];
  private particles: Particle[] = [];
  private camera: { x: number; y: number } = { x: 0, y: 0 };
  private lastTime = 0;
  private isRunning = false;
  private keys: { [key: string]: boolean } = {};

  constructor(canvas: HTMLCanvasElement, levelNumber: number) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    
    // Enable pixel-perfect rendering
    this.ctx.imageSmoothingEnabled = false;
    
    this.level = new Level(levelNumber);
    this.player = new Player(100, 300);
    
    this.setupInput();
    this.spawnEnemies();
    this.spawnPowerUps();
  }

  private setupInput() {
    const handleKeyDown = (e: KeyboardEvent) => {
      this.keys[e.code] = true;
      
      // Pause game with ESC
      if (e.code === 'Escape') {
        const gameState = useGameState.getState();
        if (gameState.gameState === 'playing') {
          gameState.pauseGame();
        } else if (gameState.gameState === 'paused') {
          gameState.resumeGame();
        }
      }
      
      e.preventDefault();
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      this.keys[e.code] = false;
      e.preventDefault();
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
  }

  private spawnEnemies() {
    // Spawn enemies based on level
    const levelData = this.level.getLevelData();
    
    // Clear existing enemies
    this.enemies = [];
    
    // Spawn mushroom enemies
    for (let i = 0; i < levelData.enemies.mushrooms; i++) {
      const x = 300 + i * 400 + Math.random() * 200;
      const y = this.level.getGroundLevel(x) - 32;
      this.enemies.push(new Mushroom(x, y));
    }
    
    // Spawn turtle enemies
    for (let i = 0; i < levelData.enemies.turtles; i++) {
      const x = 500 + i * 500 + Math.random() * 300;
      const y = this.level.getGroundLevel(x) - 32;
      this.enemies.push(new Turtle(x, y));
    }
  }

  private spawnPowerUps() {
    const levelData = this.level.getLevelData();
    
    // Clear existing power-ups
    this.powerUps = [];
    
    // Spawn mushroom power-ups
    for (let i = 0; i < 3; i++) {
      const x = 400 + i * 600;
      const y = this.level.getGroundLevel(x) - 32;
      this.powerUps.push(new MushroomPowerUp(x, y));
    }
    
    // Spawn fire flower
    if (levelData.theme !== 'underground') {
      const x = 800;
      const y = this.level.getGroundLevel(x) - 32;
      this.powerUps.push(new FireFlowerPowerUp(x, y));
    }
    
    // Spawn star
    const x = 1200;
    const y = this.level.getGroundLevel(x) - 32;
    this.powerUps.push(new StarPowerUp(x, y));
  }

  start() {
    this.isRunning = true;
    this.gameLoop(0);
    
    // Start background music
    const audio = useAudio.getState();
    if (audio.backgroundMusic && !audio.isMuted) {
      audio.backgroundMusic.play().catch(console.log);
    }
  }

  stop() {
    this.isRunning = false;
    
    // Stop background music
    const audio = useAudio.getState();
    if (audio.backgroundMusic) {
      audio.backgroundMusic.pause();
    }
  }

  pause() {
    this.isRunning = false;
  }

  resume() {
    if (!this.isRunning) {
      this.isRunning = true;
      this.gameLoop(performance.now());
    }
  }

  private gameLoop(currentTime: number) {
    if (!this.isRunning) return;

    const deltaTime = Math.min((currentTime - this.lastTime) / 1000, 1/30); // Cap at 30 FPS for stability
    this.lastTime = currentTime;

    this.update(deltaTime);
    this.render();

    requestAnimationFrame((time) => this.gameLoop(time));
  }

  private update(deltaTime: number) {
    // Update player
    this.player.update(deltaTime, this.keys, this.level);
    
    // Update camera to follow player
    this.updateCamera();
    
    // Update enemies
    this.enemies.forEach(enemy => {
      enemy.update(deltaTime, this.level);
    });
    
    // Update power-ups
    this.powerUps.forEach(powerUp => {
      powerUp.update(deltaTime);
    });
    
    // Update particles
    this.particles = this.particles.filter(particle => {
      particle.update(deltaTime);
      return particle.isAlive();
    });
    
    // Check collisions
    this.checkCollisions();
    
    // Check if player reached the goal
    this.checkGoalReached();
    
    // Check if player fell off the map
    if (this.player.y > this.canvas.height + 100) {
      useGameState.getState().loseLife();
    }
  }

  private updateCamera() {
    // Follow player with some offset
    const targetX = this.player.x - this.canvas.width / 3;
    this.camera.x = Math.max(0, targetX);
    
    // Keep camera at ground level
    this.camera.y = 0;
  }

  private checkCollisions() {
    // Player vs Enemies
    this.enemies = this.enemies.filter(enemy => {
      if (enemy.isAlive() && Collision.checkAABB(this.player.getBounds(), enemy.getBounds())) {
        if (this.player.velocityY > 0 && this.player.y < enemy.y) {
          // Player stomped on enemy
          enemy.kill();
          this.player.bounce();
          useGameState.getState().addScore(100);
          useAudio.getState().playHit();
          
          // Create particles
          for (let i = 0; i < 5; i++) {
            this.particles.push(new Particle(enemy.x, enemy.y, 'yellow'));
          }
          
          return false; // Remove enemy
        } else if (!this.player.isInvulnerable()) {
          // Player got hit
          this.player.takeDamage();
          return true;
        }
      }
      return true;
    });
    
    // Player vs Power-ups
    this.powerUps = this.powerUps.filter(powerUp => {
      if (Collision.checkAABB(this.player.getBounds(), powerUp.getBounds())) {
        powerUp.applyEffect(this.player);
        useGameState.getState().addScore(200);
        useAudio.getState().playSuccess();
        
        // Create particles
        for (let i = 0; i < 8; i++) {
          this.particles.push(new Particle(powerUp.x, powerUp.y, powerUp.getColor()));
        }
        
        return false; // Remove power-up
      }
      return true;
    });
    
    // Check coin collection
    const coinPositions = this.level.getCoinPositions();
    coinPositions.forEach((coin, index) => {
      if (coin.collected) return;
      
      const coinBounds = { x: coin.x, y: coin.y, width: 24, height: 24 };
      if (Collision.checkAABB(this.player.getBounds(), coinBounds)) {
        coin.collected = true;
        useGameState.getState().addCoin();
        useAudio.getState().playSuccess();
        
        // Create particles
        for (let i = 0; i < 3; i++) {
          this.particles.push(new Particle(coin.x, coin.y, 'gold'));
        }
      }
    });
  }

  private checkGoalReached() {
    const goalX = this.level.getLevelData().goalX;
    if (this.player.x >= goalX) {
      useGameState.getState().completeLevel();
    }
  }

  private render() {
    // Clear canvas
    this.ctx.fillStyle = this.level.getSkyColor();
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Save context for camera transformation
    this.ctx.save();
    this.ctx.translate(-this.camera.x, -this.camera.y);
    
    // Render level
    this.level.render(this.ctx, this.camera, this.canvas.width, this.canvas.height);
    
    // Render enemies
    this.enemies.forEach(enemy => {
      enemy.render(this.ctx);
    });
    
    // Render power-ups
    this.powerUps.forEach(powerUp => {
      powerUp.render(this.ctx);
    });
    
    // Render particles
    this.particles.forEach(particle => {
      particle.render(this.ctx);
    });
    
    // Render player
    this.player.render(this.ctx);
    
    // Restore context
    this.ctx.restore();
  }
}
