export interface LevelData {
  theme: 'grassland' | 'underground' | 'castle';
  goalX: number;
  enemies: {
    mushrooms: number;
    turtles: number;
  };
}

export interface Coin {
  x: number;
  y: number;
  collected: boolean;
}

export class Level {
  private levelNumber: number;
  private levelData: LevelData;
  private coins: Coin[] = [];
  private platforms: Array<{ x: number; y: number; width: number; height: number }> = [];

  constructor(levelNumber: number) {
    this.levelNumber = levelNumber;
    this.levelData = this.getLevelConfiguration(levelNumber);
    this.generateCoins();
    this.generatePlatforms();
  }

  private getLevelConfiguration(level: number): LevelData {
    switch (level) {
      case 1:
        return {
          theme: 'grassland',
          goalX: 2000,
          enemies: { mushrooms: 3, turtles: 2 }
        };
      case 2:
        return {
          theme: 'underground',
          goalX: 2500,
          enemies: { mushrooms: 4, turtles: 3 }
        };
      case 3:
        return {
          theme: 'castle',
          goalX: 3000,
          enemies: { mushrooms: 5, turtles: 4 }
        };
      default:
        return {
          theme: 'grassland',
          goalX: 2000,
          enemies: { mushrooms: 3, turtles: 2 }
        };
    }
  }

  private generateCoins() {
    this.coins = [];
    const coinCount = 10 + this.levelNumber * 5;
    
    for (let i = 0; i < coinCount; i++) {
      const x = 200 + i * 150 + (Math.random() - 0.5) * 100;
      const y = this.getGroundLevel(x) - 100 - Math.random() * 100;
      this.coins.push({ x, y, collected: false });
    }
  }

  private generatePlatforms() {
    this.platforms = [];
    
    // Generate some floating platforms
    for (let i = 0; i < 5; i++) {
      const x = 400 + i * 300;
      const y = 200 + Math.sin(i) * 50;
      this.platforms.push({ x, y, width: 120, height: 20 });
    }
  }

  getGroundLevel(x: number): number {
    // Vary ground height slightly based on position and theme
    const baseHeight = 400;
    let variation = 0;
    
    if (this.levelData.theme === 'grassland') {
      variation = Math.sin(x * 0.01) * 20;
    } else if (this.levelData.theme === 'underground') {
      variation = Math.sin(x * 0.02) * 30;
    } else if (this.levelData.theme === 'castle') {
      variation = Math.sin(x * 0.005) * 10;
    }
    
    return baseHeight + variation;
  }

  getSkyColor(): string {
    switch (this.levelData.theme) {
      case 'grassland':
        return '#87CEEB'; // Sky blue
      case 'underground':
        return '#2F1B14'; // Dark brown
      case 'castle':
        return '#4A4A4A'; // Dark gray
      default:
        return '#87CEEB';
    }
  }

  getGroundColor(): string {
    switch (this.levelData.theme) {
      case 'grassland':
        return '#90EE90'; // Light green
      case 'underground':
        return '#8B4513'; // Saddle brown
      case 'castle':
        return '#696969'; // Dim gray
      default:
        return '#90EE90';
    }
  }

  getLevelData(): LevelData {
    return this.levelData;
  }

  getCoinPositions(): Coin[] {
    return this.coins;
  }

  getWidth(): number {
    return this.levelData.goalX + 200;
  }

  render(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, screenWidth: number, screenHeight: number) {
    const startX = Math.floor(camera.x / 50) * 50;
    const endX = startX + screenWidth + 100;
    
    // Draw ground
    ctx.fillStyle = this.getGroundColor();
    for (let x = startX; x < endX; x += 50) {
      const groundY = this.getGroundLevel(x);
      ctx.fillRect(x, groundY, 50, screenHeight - groundY);
      
      // Add grass texture for grassland
      if (this.levelData.theme === 'grassland') {
        ctx.fillStyle = '#006400'; // Dark green for grass
        for (let i = 0; i < 5; i++) {
          const grassX = x + i * 10 + 5;
          ctx.fillRect(grassX, groundY - 5, 2, 5);
        }
        ctx.fillStyle = this.getGroundColor();
      }
    }
    
    // Draw platforms
    ctx.fillStyle = '#8B4513'; // Brown platforms
    this.platforms.forEach(platform => {
      ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      
      // Platform outline
      ctx.strokeStyle = '#654321';
      ctx.lineWidth = 2;
      ctx.strokeRect(platform.x, platform.y, platform.width, platform.height);
    });
    
    // Draw coins
    this.coins.forEach(coin => {
      if (coin.collected) return;
      
      // Spinning coin effect
      const spinTime = Date.now() * 0.01;
      const width = Math.abs(Math.sin(spinTime)) * 20 + 4;
      
      ctx.fillStyle = '#FFD700'; // Gold
      ctx.fillRect(coin.x + (24 - width) / 2, coin.y, width, 24);
      
      // Coin outline
      ctx.strokeStyle = '#FFA500'; // Orange outline
      ctx.lineWidth = 1;
      ctx.strokeRect(coin.x + (24 - width) / 2, coin.y, width, 24);
    });
    
    // Draw breakable blocks
    ctx.fillStyle = '#D2B48C'; // Tan for blocks
    for (let x = startX; x < endX; x += 200) {
      const blockY = this.getGroundLevel(x) - 150;
      if (Math.random() > 0.7) { // 30% chance for blocks
        this.drawBlock(ctx, x, blockY);
      }
    }
    
    // Draw goal flag
    const goalX = this.levelData.goalX;
    if (goalX >= camera.x - 100 && goalX <= camera.x + screenWidth + 100) {
      this.drawGoalFlag(ctx, goalX);
    }
    
    // Draw background elements based on theme
    this.drawBackgroundElements(ctx, camera, screenWidth, screenHeight);
  }

  private drawBlock(ctx: CanvasRenderingContext2D, x: number, y: number) {
    const blockSize = 32;
    
    // Block base
    ctx.fillStyle = '#D2B48C';
    ctx.fillRect(x, y, blockSize, blockSize);
    
    // Block pattern
    ctx.fillStyle = '#F5DEB3';
    ctx.fillRect(x + 4, y + 4, 8, 8);
    ctx.fillRect(x + 20, y + 4, 8, 8);
    ctx.fillRect(x + 4, y + 20, 8, 8);
    ctx.fillRect(x + 20, y + 20, 8, 8);
    
    // Block outline
    ctx.strokeStyle = '#A0522D';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, blockSize, blockSize);
  }

  private drawGoalFlag(ctx: CanvasRenderingContext2D, x: number) {
    const groundY = this.getGroundLevel(x);
    const flagPoleHeight = 200;
    
    // Flag pole
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(x, groundY - flagPoleHeight, 8, flagPoleHeight);
    
    // Flag
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(x + 8, groundY - flagPoleHeight + 20, 60, 40);
    
    // Flag pattern
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + 16, groundY - flagPoleHeight + 28, 12, 8);
    ctx.fillRect(x + 36, groundY - flagPoleHeight + 28, 12, 8);
    ctx.fillRect(x + 16, groundY - flagPoleHeight + 44, 12, 8);
    ctx.fillRect(x + 36, groundY - flagPoleHeight + 44, 12, 8);
  }

  private drawBackgroundElements(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, screenWidth: number, screenHeight: number) {
    const startX = camera.x;
    const endX = startX + screenWidth;
    
    if (this.levelData.theme === 'grassland') {
      // Draw clouds
      ctx.fillStyle = '#FFFFFF';
      for (let x = startX; x < endX; x += 300) {
        const cloudX = x + ((x * 0.2) % 300);
        const cloudY = 50 + Math.sin(cloudX * 0.01) * 20;
        this.drawCloud(ctx, cloudX, cloudY);
      }
      
      // Draw hills in background
      ctx.fillStyle = '#90EE90';
      for (let x = startX; x < endX; x += 100) {
        const hillX = x + ((x * 0.1) % 100);
        const hillY = 300 + Math.sin(hillX * 0.005) * 50;
        ctx.fillRect(hillX, hillY, 200, 100);
      }
    } else if (this.levelData.theme === 'underground') {
      // Draw stalactites
      ctx.fillStyle = '#696969';
      for (let x = startX; x < endX; x += 150) {
        const stalaX = x + ((x * 0.3) % 150);
        ctx.fillRect(stalaX, 0, 20, 80 + Math.random() * 40);
      }
    } else if (this.levelData.theme === 'castle') {
      // Draw castle walls
      ctx.fillStyle = '#A0A0A0';
      for (let x = startX; x < endX; x += 200) {
        const wallX = x + ((x * 0.15) % 200);
        ctx.fillRect(wallX, 150, 50, 250);
        
        // Battlements
        ctx.fillRect(wallX - 5, 145, 10, 15);
        ctx.fillRect(wallX + 45, 145, 10, 15);
      }
    }
  }

  private drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number) {
    // Simple cloud shape
    ctx.fillRect(x, y + 10, 60, 20);
    ctx.fillRect(x + 10, y, 40, 30);
    ctx.fillRect(x + 20, y + 5, 20, 25);
  }
}
