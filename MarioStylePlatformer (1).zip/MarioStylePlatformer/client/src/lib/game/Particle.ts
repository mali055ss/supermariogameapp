export class Particle {
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;

  constructor(x: number, y: number, color: string) {
    this.x = x;
    this.y = y;
    this.velocityX = (Math.random() - 0.5) * 200;
    this.velocityY = -Math.random() * 150 - 50;
    this.life = 1.0;
    this.maxLife = 1.0;
    this.color = color;
    this.size = 4 + Math.random() * 4;
  }

  update(deltaTime: number) {
    // Update position
    this.x += this.velocityX * deltaTime;
    this.y += this.velocityY * deltaTime;
    
    // Apply gravity
    this.velocityY += 300 * deltaTime;
    
    // Reduce life
    this.life -= deltaTime * 2;
    
    // Fade out
    if (this.life < 0) {
      this.life = 0;
    }
  }

  isAlive(): boolean {
    return this.life > 0;
  }

  render(ctx: CanvasRenderingContext2D) {
    if (!this.isAlive()) return;
    
    const alpha = this.life / this.maxLife;
    
    ctx.save();
    ctx.globalAlpha = alpha;
    
    // Set color based on particle type
    switch (this.color) {
      case 'yellow':
        ctx.fillStyle = '#ffff00';
        break;
      case 'gold':
        ctx.fillStyle = '#ffd700';
        break;
      case 'red':
        ctx.fillStyle = '#ff0000';
        break;
      case 'orange':
        ctx.fillStyle = '#ff6600';
        break;
      default:
        ctx.fillStyle = this.color;
    }
    
    // Draw particle
    ctx.fillRect(this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    
    ctx.restore();
  }
}
