import { Collision } from './Collision';
import { Level } from './Level';

export enum PlayerState {
  SMALL = 'small',
  BIG = 'big',
  FIRE = 'fire'
}

export class Player {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number = 0;
  velocityY: number = 0;
  
  private state: PlayerState = PlayerState.SMALL;
  private onGround: boolean = false;
  private facing: 'left' | 'right' = 'right';
  private invulnerabilityTime: number = 0;
  private starTime: number = 0;
  private animationFrame: number = 0;
  private animationTime: number = 0;
  
  private readonly GRAVITY = 800;
  private readonly JUMP_FORCE = -350;
  private readonly MOVE_SPEED = 200;
  private readonly MAX_FALL_SPEED = 600;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.width = 32;
    this.height = 32;
  }

  update(deltaTime: number, keys: { [key: string]: boolean }, level: Level) {
    // Handle input
    this.handleInput(keys);
    
    // Apply gravity
    this.velocityY += this.GRAVITY * deltaTime;
    this.velocityY = Math.min(this.velocityY, this.MAX_FALL_SPEED);
    
    // Update position
    this.x += this.velocityX * deltaTime;
    this.y += this.velocityY * deltaTime;
    
    // Collision with level
    this.handleLevelCollision(level);
    
    // Update timers
    if (this.invulnerabilityTime > 0) {
      this.invulnerabilityTime -= deltaTime;
    }
    
    if (this.starTime > 0) {
      this.starTime -= deltaTime;
    }
    
    // Update animation
    this.animationTime += deltaTime;
    if (this.animationTime > 0.1) {
      this.animationFrame = (this.animationFrame + 1) % 4;
      this.animationTime = 0;
    }
  }

  private handleInput(keys: { [key: string]: boolean }) {
    // Horizontal movement
    this.velocityX = 0;
    
    if (keys['ArrowLeft'] || keys['KeyA']) {
      this.velocityX = -this.MOVE_SPEED;
      this.facing = 'left';
    }
    
    if (keys['ArrowRight'] || keys['KeyD']) {
      this.velocityX = this.MOVE_SPEED;
      this.facing = 'right';
    }
    
    // Jumping
    if ((keys['Space'] || keys['ArrowUp'] || keys['KeyW']) && this.onGround) {
      this.velocityY = this.JUMP_FORCE;
      this.onGround = false;
    }
  }

  private handleLevelCollision(level: Level) {
    // Ground collision
    const groundY = level.getGroundLevel(this.x);
    
    if (this.y + this.height >= groundY && this.velocityY >= 0) {
      this.y = groundY - this.height;
      this.velocityY = 0;
      this.onGround = true;
    } else {
      this.onGround = false;
    }
    
    // Side boundaries
    this.x = Math.max(0, this.x);
  }

  bounce() {
    this.velocityY = this.JUMP_FORCE * 0.5;
  }

  takeDamage() {
    if (this.invulnerabilityTime > 0 || this.starTime > 0) return;
    
    if (this.state === PlayerState.FIRE) {
      this.state = PlayerState.BIG;
    } else if (this.state === PlayerState.BIG) {
      this.state = PlayerState.SMALL;
      this.height = 32;
    } else {
      // Player dies
      import('../stores/useGameState').then(({ useGameState }) => {
        useGameState.getState().loseLife();
      });
      return;
    }
    
    this.invulnerabilityTime = 1.5;
  }

  powerUp(type: 'mushroom' | 'fire' | 'star') {
    switch (type) {
      case 'mushroom':
        if (this.state === PlayerState.SMALL) {
          this.state = PlayerState.BIG;
          this.height = 48;
        }
        break;
      case 'fire':
        this.state = PlayerState.FIRE;
        this.height = 48;
        break;
      case 'star':
        this.starTime = 10; // 10 seconds of invincibility
        break;
    }
  }

  isInvulnerable(): boolean {
    return this.invulnerabilityTime > 0 || this.starTime > 0;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height
    };
  }

  render(ctx: CanvasRenderingContext2D) {
    ctx.save();
    
    // Flashing effect when invulnerable
    if (this.isInvulnerable() && Math.floor(Date.now() / 100) % 2) {
      ctx.globalAlpha = 0.5;
    }
    
    // Star power effect
    if (this.starTime > 0) {
      const hue = (Date.now() / 50) % 360;
      ctx.filter = `hue-rotate(${hue}deg) brightness(1.5)`;
    }
    
    const isMoving = Math.abs(this.velocityX) > 0;
    const isJumping = !this.onGround;
    
    // Animation frame for walking
    let frame = 0;
    if (isMoving && this.onGround) {
      frame = this.animationFrame % 2;
    }
    
    // Colors based on state
    let skinColor = '#FFDBAC'; // Peach/skin tone
    let shirtColor = this.state === PlayerState.FIRE ? '#ffffff' : '#ff0000'; // White for fire, red for normal
    let overallsColor = '#0066ff'; // Blue overalls
    let hatColor = '#ff0000'; // Red hat
    let shoeColor = '#8B4513'; // Brown shoes
    
    // Draw Mario pixel by pixel for authentic look
    const pixelSize = 2;
    const offsetX = this.x;
    const offsetY = this.y;
    
    // Mario sprite pattern (simplified pixel art)
    const marioSprite = this.getMarioSprite(frame, isJumping);
    
    // Handle facing direction by flipping horizontally
    if (this.facing === 'left') {
      ctx.save();
      ctx.scale(-1, 1);
      ctx.translate(-this.x - this.width, 0);
    }
    
    for (let row = 0; row < marioSprite.length; row++) {
      for (let col = 0; col < marioSprite[row].length; col++) {
        const pixel = marioSprite[row][col];
        if (pixel === '.') continue; // Transparent
        
        let color = '#000000';
        switch (pixel) {
          case 'H': color = hatColor; break; // Hat
          case 'S': color = skinColor; break; // Skin
          case 'E': color = '#000000'; break; // Eyes/outline
          case 'M': color = '#654321'; break; // Mustache
          case 'T': color = shirtColor; break; // Shirt
          case 'O': color = overallsColor; break; // Overalls
          case 'B': color = '#FFD700'; break; // Buttons
          case 'F': color = shoeColor; break; // Feet/shoes
          case 'G': color = '#FFFFFF'; break; // Gloves
        }
        
        ctx.fillStyle = color;
        ctx.fillRect(
          offsetX + col * pixelSize,
          offsetY + row * pixelSize,
          pixelSize,
          pixelSize
        );
      }
    }
    
    if (this.facing === 'left') {
      ctx.restore();
    }
    
    ctx.restore();
  }
  
  private getMarioSprite(frame: number, isJumping: boolean): string[] {
    // Basic Mario sprite pattern (16x16 for small, 16x24 for big)
    if (this.state === PlayerState.SMALL) {
      if (isJumping) {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '..GGTTTTTGG...',
          '...GGGGGGG....',
          '..GGGG.GGGG...',
          '.FFFF...FFFF..',
          'FFFF.....FFFF.',
          'FFF.......FFF.'
        ];
      } else if (frame === 0) {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '..GGTTTTTGG...',
          '...GGGGGGG....',
          '...GGG.GGG....',
          '..FFFF.FFFF...',
          '..FFFF.FFFF...',
          '..............'
        ];
      } else {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '..GGTTTTTGG...',
          '...GGGGGGG....',
          '..GGG...GGG...',
          '..FFF...FFF...',
          '.FFF.....FFF..',
          '..............'
        ];
      }
    } else {
      // Big Mario (taller sprite)
      if (isJumping) {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '...OOOOOOO....',
          '..OOOOOOOOO...',
          '..OOOOOOOOO...',
          '..GGOOOOOGG...',
          '...GGGGGGG....',
          '..GGGG.GGGG...',
          '.FFFF...FFFF..',
          'FFFF.....FFFF.',
          'FFF.......FFF.',
          '..............',
          '..............',
          '..............',
          '..............',
          '..............'
        ];
      } else if (frame === 0) {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '...OOOOOOO....',
          '..OOOOOOOOO...',
          '..OOOOOOOOO...',
          '..GGOOOOOGG...',
          '...GGGGGGG....',
          '...GGG.GGG....',
          '..FFFF.FFFF...',
          '..FFFF.FFFF...',
          '..............',
          '..............',
          '..............',
          '..............',
          '..............',
          '..............'
        ];
      } else {
        return [
          '....HHHHHH....',
          '...HHHHHHHH...',
          '...EESESSSSS..',
          '..ESEESSSESS..',
          '..ESEEESSSE...',
          '..SSSMMMMSSS..',
          '....MMMMMM....',
          '...TTTTTTT....',
          '..TOTTTTOTT...',
          '..TTTTTTTTT...',
          '...OOOOOOO....',
          '..OOOOOOOOO...',
          '..OOOOOOOOO...',
          '..GGOOOOOGG...',
          '...GGGGGGG....',
          '..GGG...GGG...',
          '..FFF...FFF...',
          '.FFF.....FFF..',
          '..............',
          '..............',
          '..............',
          '..............',
          '..............',
          '..............'
        ];
      }
    }
  }
}
