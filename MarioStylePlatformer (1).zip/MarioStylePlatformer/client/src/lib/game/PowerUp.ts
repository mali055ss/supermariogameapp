import { Player } from './Player';

export abstract class PowerUp {
  x: number;
  y: number;
  width: number;
  height: number;
  
  protected animationTime: number = 0;
  protected bobOffset: number = 0;

  constructor(x: number, y: number, width: number, height: number) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  update(deltaTime: number) {
    // Bobbing animation
    this.animationTime += deltaTime * 2;
    this.bobOffset = Math.sin(this.animationTime) * 5;
  }

  getBounds() {
    return {
      x: this.x,
      y: this.y + this.bobOffset,
      width: this.width,
      height: this.height
    };
  }

  abstract applyEffect(player: Player): void;
  abstract getColor(): string;
  abstract render(ctx: CanvasRenderingContext2D): void;
}

export class MushroomPowerUp extends PowerUp {
  constructor(x: number, y: number) {
    super(x, y, 24, 24);
  }

  applyEffect(player: Player) {
    player.powerUp('mushroom');
  }

  getColor(): string {
    return 'red';
  }

  render(ctx: CanvasRenderingContext2D) {
    const renderY = this.y + this.bobOffset;
    
    // Mushroom stem (white)
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 8, renderY + 12, 8, 12);
    
    // Mushroom cap (red)
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(this.x, renderY, this.width, 16);
    
    // White spots
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 4, renderY + 4, 4, 4);
    ctx.fillRect(this.x + 16, renderY + 4, 4, 4);
    ctx.fillRect(this.x + 10, renderY + 10, 4, 4);
  }
}

export class FireFlowerPowerUp extends PowerUp {
  constructor(x: number, y: number) {
    super(x, y, 24, 24);
  }

  applyEffect(player: Player) {
    player.powerUp('fire');
  }

  getColor(): string {
    return 'orange';
  }

  render(ctx: CanvasRenderingContext2D) {
    const renderY = this.y + this.bobOffset;
    
    // Flower stem (green)
    ctx.fillStyle = '#00aa00';
    ctx.fillRect(this.x + 10, renderY + 16, 4, 8);
    
    // Flower petals (orange/red)
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(this.x + 8, renderY, 8, 8);  // Top
    ctx.fillRect(this.x, renderY + 8, 8, 8);  // Left
    ctx.fillRect(this.x + 16, renderY + 8, 8, 8);  // Right
    ctx.fillRect(this.x + 8, renderY + 16, 8, 8);  // Bottom
    
    // Flower center (yellow)
    ctx.fillStyle = '#ffff00';
    ctx.fillRect(this.x + 8, renderY + 8, 8, 8);
  }
}

export class StarPowerUp extends PowerUp {
  constructor(x: number, y: number) {
    super(x, y, 24, 24);
  }

  applyEffect(player: Player) {
    player.powerUp('star');
  }

  getColor(): string {
    return 'yellow';
  }

  render(ctx: CanvasRenderingContext2D) {
    const renderY = this.y + this.bobOffset;
    const centerX = this.x + this.width / 2;
    const centerY = renderY + this.height / 2;
    
    // Rotating star effect
    const rotation = this.animationTime * 2;
    
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(rotation);
    
    // Star shape (yellow with rainbow effect)
    const hue = (this.animationTime * 100) % 360;
    ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;
    
    // Draw star using path
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * Math.PI * 2) / 5;
      const x1 = Math.cos(angle) * 12;
      const y1 = Math.sin(angle) * 12;
      const x2 = Math.cos(angle + Math.PI / 5) * 5;
      const y2 = Math.sin(angle + Math.PI / 5) * 5;
      
      if (i === 0) ctx.moveTo(x1, y1);
      else ctx.lineTo(x1, y1);
      ctx.lineTo(x2, y2);
    }
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
  }
}
