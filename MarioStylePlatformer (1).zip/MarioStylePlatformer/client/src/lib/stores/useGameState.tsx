import { create } from "zustand";

export type GameState = 'menu' | 'playing' | 'paused' | 'levelComplete' | 'gameOver';

interface GameStateStore {
  gameState: GameState;
  currentLevel: number;
  lives: number;
  score: number;
  coins: number;
  
  // Actions
  startGame: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
  completeLevel: () => void;
  loseLife: () => void;
  resetGame: () => void;
  restartLevel: () => void;
  addScore: (points: number) => void;
  addCoin: () => void;
  nextLevel: () => void;
}

export const useGameState = create<GameStateStore>((set, get) => ({
  gameState: 'menu',
  currentLevel: 1,
  lives: 3,
  score: 0,
  coins: 0,
  
  startGame: () => {
    set({ 
      gameState: 'playing',
      currentLevel: 1,
      lives: 3,
      score: 0,
      coins: 0
    });
  },
  
  pauseGame: () => {
    if (get().gameState === 'playing') {
      set({ gameState: 'paused' });
    }
  },
  
  resumeGame: () => {
    if (get().gameState === 'paused') {
      set({ gameState: 'playing' });
    }
  },
  
  completeLevel: () => {
    set({ gameState: 'levelComplete' });
  },
  
  loseLife: () => {
    const { lives } = get();
    if (lives > 1) {
      set({ lives: lives - 1, gameState: 'playing' });
    } else {
      set({ lives: 0, gameState: 'gameOver' });
    }
  },
  
  resetGame: () => {
    set({ 
      gameState: 'menu',
      currentLevel: 1,
      lives: 3,
      score: 0,
      coins: 0
    });
  },
  
  addScore: (points: number) => {
    set(state => ({ score: state.score + points }));
  },
  
  addCoin: () => {
    set(state => ({ 
      coins: state.coins + 1,
      score: state.score + 100
    }));
  },
  
  nextLevel: () => {
    set(state => ({ 
      currentLevel: state.currentLevel + 1,
      gameState: 'playing'
    }));
  },
  
  restartLevel: () => {
    set(state => ({ 
      gameState: 'playing',
      lives: state.lives,
      score: state.score,
      coins: state.coins,
      currentLevel: state.currentLevel
    }));
  }
}));
