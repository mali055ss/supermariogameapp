
#!/bin/bash

echo "🔧 Fixing Git Lock Issues..."
echo "============================"

# Remove lock files
rm -f .git/index.lock 2>/dev/null
rm -f .git/config.lock 2>/dev/null
rm -f /home/runner/workspace/.git/index.lock 2>/dev/null
rm -f /home/runner/workspace/.git/config.lock 2>/dev/null

# Reset Git config
git config --unset user.name 2>/dev/null
git config --unset user.email 2>/dev/null

# Set proper Git config
git config user.name "SuperMario Developer"
git config user.email "supermario.dev@gmail.com"

echo "✅ Git locks cleared!"
echo "✅ Git config reset!"
echo ""
echo "You can now run:"
echo "  - git status"
echo "  - git add ."
echo "  - git commit -m 'Your message'"
echo ""
echo "🎮 Ready for GitHub setup!"
