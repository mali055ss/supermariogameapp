
#!/usr/bin/env node

const readline = require('readline');
const fs = require('fs');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('🎮 Super Mario Platformer - URL Generator 🎮');
console.log('===============================================');

rl.question('Enter your GitHub username: ', (username) => {
  if (!username) {
    console.log('❌ Username is required!');
    rl.close();
    return;
  }

  // Generate URLs
  const repoUrl = `https://github.com/${username}/super-mario-platformer`;
  const liveUrl = `https://super-mario-platformer.replit.app`;
  
  console.log('\n✅ Your Custom URLs:');
  console.log('=====================');
  console.log(`📂 Repository: ${repoUrl}`);
  console.log(`🌐 Live Game: ${liveUrl}`);
  console.log(`📋 Clone URL: ${repoUrl}.git`);
  
  // Save to file
  const urlInfo = {
    username: username,
    repository: repoUrl,
    liveGame: liveUrl,
    cloneUrl: `${repoUrl}.git`,
    generatedAt: new Date().toISOString()
  };
  
  fs.writeFileSync('github-urls.json', JSON.stringify(urlInfo, null, 2));
  console.log('\n💾 URLs saved to github-urls.json');
  
  console.log('\n🚀 Next Steps:');
  console.log('1. Create repository on GitHub with name: super-mario-platformer');
  console.log('2. Run: git add .');
  console.log('3. Run: git commit -m "Initial commit"');
  console.log(`4. Run: git remote add origin ${repoUrl}.git`);
  console.log('5. Run: git push -u origin main');
  
  rl.close();
});

