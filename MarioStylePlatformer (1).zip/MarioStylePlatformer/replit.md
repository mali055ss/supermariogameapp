# Super Mario Platformer Game

## Overview

This project is a Super Mario-style platformer game built with modern web technologies. It features a full-stack architecture with a React frontend game engine, Express.js backend, and PostgreSQL database. The game includes classic platformer mechanics like jumping, collecting coins, defeating enemies, and progressing through multiple levels.

## System Architecture

The application follows a monorepo structure with clear separation between client, server, and shared components:

- **Frontend**: React-based game engine using HTML5 Canvas for rendering
- **Backend**: Express.js server with RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Shared**: Common schemas and types used across client and server
- **Build System**: Vite for frontend bundling, esbuild for server compilation

## Key Components

### Frontend Architecture
- **Game Engine**: Custom HTML5 Canvas-based game engine (`GameEngine.ts`)
- **Game Systems**: 
  - Player controller with physics and state management
  - Enemy AI system with collision detection
  - Level generation and progression system
  - Particle effects and audio management
- **UI Framework**: React with Radix UI components and Tailwind CSS
- **State Management**: Zustand stores for game state and audio management
- **Asset Handling**: Support for GLTF/GLB models, audio files, and GLSL shaders

### Backend Architecture
- **Server Framework**: Express.js with TypeScript
- **Storage Layer**: Abstract storage interface with in-memory implementation
- **API Routes**: RESTful endpoints under `/api` prefix
- **Development Setup**: Vite middleware integration for hot reloading

### Game Systems
- **Physics Engine**: Custom collision detection with AABB collision resolution
- **Entity System**: Object-oriented approach with Player, Enemy, PowerUp, and Particle classes
- **Level System**: Configurable levels with different themes and difficulty progression
- **Audio System**: HTML5 Audio with mute controls and sound effect management

## Data Flow

1. **Game Loop**: Canvas-based rendering at 60fps with delta time calculations
2. **Input Handling**: Keyboard events processed through the game engine
3. **State Updates**: Game state flows through Zustand stores to React components
4. **Level Progression**: Automatic level advancement with difficulty scaling
5. **Score System**: Real-time score updates with coin collection and enemy defeats

## External Dependencies

### Core Framework Dependencies
- React 18 with TypeScript for component architecture
- Express.js for server-side API handling
- Drizzle ORM with PostgreSQL for database operations
- Vite for modern build tooling and development experience

### UI and Styling
- Radix UI for accessible component primitives
- Tailwind CSS for utility-first styling
- Lucide React for consistent iconography

### Game-Specific Libraries
- Three.js ecosystem (@react-three/fiber, @react-three/drei) for potential 3D enhancements
- TanStack Query for efficient data fetching and caching
- Zustand for lightweight state management

### Development Tools
- TypeScript for type safety across the entire stack
- ESBuild for fast server compilation
- PostCSS with Autoprefixer for CSS processing

## Deployment Strategy

The application uses a hybrid deployment approach:

1. **Development**: Vite dev server with Express.js backend integration
2. **Production Build**: 
   - Frontend: Vite builds React app to `dist/public`
   - Backend: ESBuild compiles TypeScript server to `dist/index.js`
3. **Database**: PostgreSQL with Drizzle migrations managed via `drizzle-kit`
4. **Environment**: NODE_ENV-based configuration switching

### Build Commands
- `npm run dev`: Start development server with hot reloading
- `npm run build`: Create production build for both client and server
- `npm run start`: Run production server
- `npm run db:push`: Push database schema changes

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 02, 2025. Initial setup
- July 02, 2025. Added pause menu functionality with ESC key support, resume, restart level, sound toggle, and main menu options