
#!/bin/bash

echo "🎮 Super Mario Platformer - GitHub Setup 🎮"
echo "============================================="

# Clear any existing Git locks
echo "🔧 Clearing Git locks..."
rm -f .git/index.lock 2>/dev/null
rm -f .git/config.lock 2>/dev/null
rm -f /home/runner/workspace/.git/index.lock 2>/dev/null
rm -f /home/runner/workspace/.git/config.lock 2>/dev/null

# Get user input for GitHub username
read -p "Enter your GitHub username: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "❌ GitHub username is required!"
    exit 1
fi

# Create the custom GitHub repository URL
REPO_URL="https://github.com/$GITHUB_USERNAME/super-mario-platformer"

echo "📂 Your custom repository URL will be: $REPO_URL"

# Add Git remote
git remote add origin $REPO_URL.git

# Update README with actual username
sed -i "s/YOUR-USERNAME/$GITHUB_USERNAME/g" README.md

# Update DEPLOYMENT_GUIDE with actual username
sed -i "s/YOUR-USERNAME/$GITHUB_USERNAME/g" DEPLOYMENT_GUIDE.md

echo "✅ GitHub setup complete!"
echo "🔗 Repository URL: $REPO_URL"
echo ""
echo "Next steps:"
echo "1. Create repository '$GITHUB_USERNAME/super-mario-platformer' on GitHub"
echo "2. Run: git add ."
echo "3. Run: git commit -m 'Initial commit: Super Mario Platformer Game'"
echo "4. Run: git push -u origin main"
echo ""
echo "🎮 Your Super Mario game will be available at:"
echo "   Repository: $REPO_URL"
echo "   Live Game: https://super-mario-platformer.replit.app"

